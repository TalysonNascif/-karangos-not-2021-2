# karangos-not-2021-2
Repositório do projeto Karangos - Programação Web - 4º semestre noturno 2021/2 Fatec Franca
