export default function ClientesForm() {
  return (
    <h1>Cadastrar novo cliente</h1>
  )
}