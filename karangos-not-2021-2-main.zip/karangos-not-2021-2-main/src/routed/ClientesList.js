export default function ClientesList() {
  return (
    <h1>Listagem de Clientes</h1>
  )
}